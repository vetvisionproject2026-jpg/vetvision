<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    //
protected $fillable = [
'user_id',
'specialization',
'experience_years',
'clinic_address',
'bio',
'contact_number',
'google_id',
'image'
];    public function user() {
    return $this->belongsTo(User::class);
}
public function availabilities()
{
    return $this->hasMany(DoctorAvailability::class);
}
}
