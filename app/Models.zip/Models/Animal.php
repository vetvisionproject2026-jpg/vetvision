<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Diagnosis; 
use Illuminate\Database\Eloquent\SoftDeletes;

class Animal extends Model
{
    use SoftDeletes;
    protected $fillable = ['owner_id', 'name', 'species', 'breed', 'age', 'gender', 'weight','image_path'];
protected $appends = ['image_path'];
    public function diagnoses()
    {
        return $this->hasMany(Diagnosis::class);
    }
  public function getImagePathAttribute($value)
{
    return $value;
}
}